<script>
    import { onMount } from 'svelte';
    import { API_CONFIG } from './config/api.js';
    
    let movies = [];
    let carregando = true;
    let erro = null;
    let busca = '';
    
    async function carregarFilmes() {
        try {
            carregando = true;
            erro = null;
            
            const url = busca 
                ? `${API_CONFIG.BASE_URL}/search/movie?query=${busca}&language=pt-BR`
                : `${API_CONFIG.BASE_URL}/movie/popular?language=pt-BR`;
                
            const resposta = await fetch(url, {
                headers: {
                    'Authorization': `Bearer ${API_CONFIG.TOKEN}`,
                    'Accept': 'application/json'
                }
            });
            
            if (!resposta.ok) throw new Error('Erro na API');
            
            const dados = await resposta.json();
            movies = dados.results || [];
            
        } catch (e) {
            erro = e.message;
        } finally {
            carregando = false;
        }
    }
    
    function limparBusca() {
        busca = '';
        carregarFilmes();
    }
    
    onMount(() => {
        carregarFilmes();
    });
</script>

<svelte:head>
    <title>Catálogo de Filmes</title>
</svelte:head>

<main>
    <h1>Catálogo de Filmes</h1>
    
    <div class="busca">
        <input 
            type="text" 
            bind:value={busca}
            placeholder="Buscar filmes..."
            on:keypress={(e) => e.key === 'Enter' && carregarFilmes()}
        />
        <button on:click={carregarFilmes}>Buscar</button>
        <button on:click={limparBusca} class="secundario">Limpar</button>
    </div>
    
    {#if carregando}
        <p>Carregando filmes...</p>
    {:else if erro}
        <p class="erro">Erro: {erro}</p>
    {:else if movies.length === 0}
        <p>Nenhum filme encontrado.</p>
    {:else}
        <div class="filmes">
            {#each movies as filme}
                <div class="filme">
                    {#if filme.poster_path}
                        <img 
                            src={`https://image.tmdb.org/t/p/w200${filme.poster_path}`} 
                            alt={filme.title}
                        />
                    {:else}
                        <div class="sem-imagem">🎭</div>
                    {/if}
                    
                    <h3>{filme.title}</h3>
                    
                    <!-- Sistema de estrelas -->
                    <div class="avaliacao">
                        {#each [1, 2, 3, 4, 5] as star}
                            {#if filme.vote_average / 2 >= star}
                                <span class="estrela cheia">★</span>
                            {:else if filme.vote_average / 2 >= star - 0.5}
                                <span class="estrela meia">★</span>
                            {:else}
                                <span class="estrela vazia">☆</span>
                            {/if}
                        {/each}
                        <span class="nota">({filme.vote_average?.toFixed(1)})</span>
                    </div>
                    
                    <p class="ano">{filme.release_date?.split('-')[0] || 'N/A'}</p>
                    
                    <!-- Resumo do filme -->
                    <p class="sinopse">
                        {#if filme.overview}
                            {filme.overview.slice(0, 100)}...
                        {:else}
                            Sinopse não disponível.
                        {/if}
                    </p>
                </div>
            {/each}
        </div>
    {/if}
</main>

<style>
    main {
        max-width: 1000px;
        margin: 0 auto;
        padding: 2rem;
        font-family: Arial, sans-serif;
    }
    
    h1 {
        text-align: center;
        color: #ff0c0cff;
        margin-bottom: 2rem;
    }
    
    .busca {
        display: flex;
        gap: 1rem;
        justify-content: center;
        margin: 2rem 0;
        flex-wrap: wrap;
    }
    
    input {
        padding: 0.75rem;
        width: 300px;
        border: 2px solid #ddd;
        border-radius: 6px;
        font-size: 1rem;
    }
    
    button {
        padding: 0.75rem 1.5rem;
        background: #007acc;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 1rem;
    }
    
    button.secundario {
        background: #f10505ff;
    }
    
    .erro {
        color: red;
        text-align: center;
        background: #ffeaea;
        padding: 1rem;
        border-radius: 6px;
    }
    
    .filmes {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 1.5rem;
        margin-top: 2rem;
    }
    
    .filme {
        background: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        text-align: center;
        transition: transform 0.2s;
    }
    
    .filme:hover {
        transform: translateY(-5px);
    }
    
    img {
        width: 100%;
        border-radius: 6px;
        margin-bottom: 1rem;
    }
    
    .sem-imagem {
        background: #f0f0f0;
        padding: 3rem 1rem;
        border-radius: 6px;
        font-size: 2rem;
        margin-bottom: 1rem;
    }
    
    h3 {
        font-size: 1rem;
        margin: 0.5rem 0;
        color: #333;
        min-height: 2.5rem;
    }
    
    .ano {
        color: #f50808ff;
        font-size: 0.9rem;
        margin: 0.25rem 0;
    }
    
    .avaliacao {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    justify-content: center;
    margin: 0.5rem 0;
    flex-wrap: nowrap;
    }
    
    .estrela {
        font-size: 1.2rem;
    color: gold;
    white-space: nowrap;
    letter-spacing: 1px;
    }
    
    .estrela.cheia {
        color: gold;
    }
    
    .estrela.meia {
        color: gold;
        opacity: 0.7;
    }
    
    .nota {
        font-size: 1rem;
    color: #0b0404ff;
    font-weight: 600;
    }

    .sinopse {
  line-height: 1.0;          
  color: #383131ff;  
  overflow: hidden;
  display: -webkit-box;
  margin: 0.3rem 1 1 2;
  font-weight: normal
  text-align: left;


}



    
</style>